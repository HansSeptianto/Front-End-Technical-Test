import React, { useState } from "react";
import './style.css';
import BtnShipment from "./BtnShipment";
import BtnPayment from "./BtnPayment";
import {
  TextField,
  Button,
  Stepper,
  Step,
  StepLabel,
  Checkbox,
  FormControl,
  FormControlLabel
} from "@material-ui/core";
import { makeStyles } from "@material-ui/core/styles";
import {
  useForm,
  Controller,
  FormProvider,
  useFormContext
} from "react-hook-form";

const useStyles = makeStyles((theme) => ({
  root: {
    "& .MuiStepIcon-active": { color: "#FF7400" },
    "& .MuiStepIcon-completed": { color: "#FF7400" },
    "& .Mui-disabled .MuiStepIcon-root": { color: "#EFAA83" }
  },
  button: {
    marginRight: theme.spacing(1),
  }
}));

let shipment=[
  {id: 1, label:"GO-SEND", value:"15,000"},
  {id: 2, label:"JNE", value:"9,000"},
  {id: 3, label:"Personal Courier", value:"29,000"},
];

let payment=[
  {id: 1, label:"e-Wallet", value:"1,500,000 left"},
  {id: 2, label:"Bank Transfer", value:"1,500,000 left"},
  {id: 3, label:"Virtual Account", value:"1,500,000 left"},
];

function getSteps() {
  return [
    "Delivery",
    "Payment",
    "Finish"
  ];
};

const isValidEmail = email =>
  // eslint-disable-next-line no-useless-escape
  /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test(
    email
  );

const Delivery = () => {
  const { control, formState: { errors }, } = useFormContext();
  const [send, setSend] = useState(false);

  const handleChange = e => {
    setSend(e.target.checked);
  };

  const handleEmailValidation = email => {
    console.log("ValidateEmail was called with", email);

    const isValid = isValidEmail(email);

    const validityChanged =
      (errors.email && isValid) || (!errors.email && !isValid);
    if (validityChanged) {
      console.log("Fire tracker with", isValid ? "Valid" : "Invalid");
    }
    return isValid;

  };
  return (
    <div className="container">
      <div className="col1">
        <div className="row">
          <p className="title">Delivery details</p>
          <Controller
            control={control}
            name="email"
            rules={{
              required: true,
              validate: handleEmailValidation,    
            }}
            render={({ field }) => (
              <TextField
                id="email"
                variant="outlined"
                placeholder="Email"
                fullWidth
                margin="normal"
                {...field}
                error={errors.email}

              />
            )}
          />
        </div>
        <div className="row">
          <Controller
            control={control}
            name="phoneNumber"
            rules={{
              required: true,
              minLength: 6,
              maxLength: 20,
            }}
            render={({ field }) => (
              <TextField
                id="phoneNumber"
                variant="outlined"
                placeholder="Phone Number"
                fullWidth
                margin="normal"
                {...field}
                error={errors.phoneNumber}
              />
            )}
          />
        </div>
        <div className="row">
          <Controller
            control={control}
            name="deliveryAddress"
            rules={{
              required: true,
              maxLength: 120,
            }}
            render={({ field }) => (
              <TextField
                id="deliveryAddress"
                variant="outlined"
                placeholder="Delivery Address"
                fullWidth
                margin="normal"
                {...field}
                error={errors.deliveryAddress}
                inputProps={{
                  style: {
                    paddingBottom: 70
                  }
                }}
              />
            )}
          />
        </div>
      </div>
      <div className="col2">
        <div className="rowCheckBox">
          <FormControl>
            <FormControlLabel 
              label="Send as dropshipper" 
              control={<Checkbox onChange={handleChange} checked={send}/>}
            />
          </FormControl>
        </div>
        {send ? (
          <div>
            <div className="row">
              <Controller
              control={control}
              name="dropshipperName"
              rules={{
                required: true,
              }}
              render={({ field }) => (
                <TextField
                  id="dropshipperName"
                  variant="outlined"
                  placeholder="Dropshipper name"
                  fullWidth
                  margin="normal"
                  {...field}
                  error={errors.dropshipperName}
                />
              )}
            />
          </div>
          <div className="row">
            <Controller
              control={control}
              name="dropshipperPhoneNumber"
              rules={{
                required: true,
                
              }}
              render={({ field }) => (
                <TextField
                  id="dropshipperPhoneNumber"
                  variant="outlined"
                  placeholder="Dropshipper phone number"
                  fullWidth
                  margin="normal"
                  {...field}
                  error={errors.dropshipperPhoneNumber}
                />
              )}
            />
          </div> 
        </div>
          ) : ( 
            ""
          )}
        
      </div>
      <div className="col3Delivery">
        <div className="line"></div>
          <h1>Summary</h1>
          <p>10 items purchased</p>
        <div className="rowText">
          <div className="colText1">
            <p>Cost of goods</p>
            <p>Dropshipping Fee</p>
            <h1>Total</h1>
          </div>
          <div className="colText2">
              <p><b>500,000</b></p>
              <p><b>5,900</b></p>
              <h1>505,900</h1>
          </div>
        </div>
      </div>
    </div>
  );
};

const Payment = () => {
  const [ValueShipment, setValueShipment] = useState(shipment[0]);
  const [ValuePayment, setValuePayment] = useState(payment[0]);

  function ChangedShipment(v){
    console.log("CHANGED", v);
    setValueShipment(v);
  }
  function ChangedPayment(v){
    console.log("CHANGED", v);
    setValuePayment(v);
  }

  return (
    <div className="container">
      <div className="col12">
        <h1 className="title">Shipment</h1>
        <div className="button">
          <BtnShipment value={shipment} OnChange={ChangedShipment}/>
        </div>
        <h1 className="title">Payment</h1>
        <div className="button">
          <BtnPayment value={payment} OnChange={ChangedPayment}/>
        </div>
      </div>
      <div className="col3">
        <div className="line2"></div>
        <h1>Summary</h1>
        <p>10 items purchased</p>
        <hr />
        <p>Delivery estimation</p>
        <p className="shipmentText">today by {ValueShipment.label}</p>
        <div className="rowText">
          <div className="colText1">
            <p>Cost of goods</p>
            <p>Dropshipping Fee</p>
            <p><b>{ValueShipment.label}</b> shipment</p>
            <h1>Total</h1>
          </div>
          <div className="colText2">
            <p><b>500,000</b></p>
            <p><b>5,900</b></p>
            <p><b>{ValueShipment.value}</b></p>
            <h1>505,900</h1>
          </div>
        </div>
      </div>
    </div>
  )
};

const Finish = () => {
  const [ValueShipment, setValueShipment] = useState(shipment[0]);
  const [ValuePayment, setValuePayment] = useState(payment[0]);

  return (
    <div className="container3">
      <div className="col12Finish">
        <h1 className="titleFinish">Thank you</h1>
        <p>Order ID: XXKYB</p>
        <p className="textFinish">Your order will delivered today with shipment</p>
        <a href="http://localhost:3000/">Go to homepage</a>
      </div>
      <div className="col3Finish">
        <div className="line3"></div>
        <h1>Summary</h1>
        <p>10 items purchased</p>
        <hr />
        <p>Delivery estimation</p>
        <p className="shipmentText">today by {ValueShipment.label}</p>
        <hr />
        <p>Payment method</p>
        <p className="shipmentText">{ValuePayment.label}</p>
        <div className="rowText">
          <div className="colText1">
            <p>Cost of goods</p>
            <p>Dropshipping Fee</p>
            <p>{ValuePayment.label} shipment</p>
            <h1>Total</h1>
          </div>
          <div className="colText2">
            <p>500,000</p>
            <p>5,900</p>
            <p>{ValuePayment.value}</p>
            <h1>505,900</h1>
          </div>
        </div>
      </div>
    </div>
  )
};

function getStepContent(step) {
  switch (step) {
    case 0:
      return <Delivery />;
    case 1:
      return <Payment />;
    case 2:
      return <Finish />;
    default:
      return <Delivery />;
  }
};

const LinearStepper = () => {
  const classes = useStyles();
  const methods = useForm({
    defaultValues: {
      email: "",
      phoneNumber: "",
      deliveryAddress: "",
      dropshipperName: "",
      dropshipperPhoneNumber: "",
    },
  });

  const [activeStep, setActiveStep] = useState(0);
  const [skippedSteps, setSkippedSteps] = useState([]);
  const steps = getSteps();

  const isStepSkipped = (step) => {
    return skippedSteps.includes(step);
  };

  const handleNext = (data) => {
    console.log(data);
    if (activeStep === steps.length - 1) {
      fetch("https://jsonplaceholder.typicode.com/comments")
        .then((data) => data.json())
        .then((res) => {
          console.log(res);
          setActiveStep(activeStep + 1);
        });
    } else {
      setActiveStep(activeStep + 1);
      setSkippedSteps(
        skippedSteps.filter((skipItem) => skipItem !== activeStep)
      );
    }
  };

  const handleBack = () => {
    setActiveStep(activeStep - 1);
  };

  return (
    <div>
      <Stepper className={classes.root} activeStep={activeStep}>
        {steps.map((step, index) => {
          const labelProps = {};
          const stepProps = {};
          if (isStepSkipped(index)) {
            stepProps.completed = false;
          }
          return (
            <Step {...stepProps} key={index}>
              <StepLabel {...labelProps}>{step}</StepLabel>
            </Step>
          );
        })}
      </Stepper>

      {activeStep === (steps.length-1) ? (
        <Finish />
        
        
      ) : (
        <>
          <FormProvider {...methods}>
            <form onSubmit={methods.handleSubmit(handleNext)}>
              {getStepContent(activeStep)}

              <Button
                className={classes.button}
                disabled={activeStep === 0}
                onClick={handleBack}
              >
                back
              </Button>
              <Button
                className={classes.button}
                variant="contained"
                color="primary"
                type="submit"
              >
                {activeStep === (steps.length-1) ? "Back" : "Continue"}
              </Button>
            </form>
          </FormProvider>
        </>
      )}
    </div>
  );
};

export default LinearStepper;