import LinearStepper from "./LinearStepper";
import { CssBaseline, Container, Paper, Box } from "@material-ui/core";
import { MuiThemeProvider, createTheme } from "@material-ui/core/styles";
import './App.css';

const themeLight = createTheme({
  palette: {
    background: {
      default: "#fff8e1"
    }
  }
});

function App() {
  return (
    <MuiThemeProvider theme={themeLight}>
      <CssBaseline />
      <Container className="container" component={Box}>
        <Paper className="paper"component={Box} p={3}>
          <LinearStepper />
        </Paper>
      </Container>
    </MuiThemeProvider>
  );
}

export default App;