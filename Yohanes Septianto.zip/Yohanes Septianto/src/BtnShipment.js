import React from "react";
import styles from "./Btn.module.css";
import { useState } from "react";

export default function BtnShipment({ value, OnChange }){
    const [current, setCurrent] = useState(value[0].id);
    
    function onClick(v){
        OnChange(v);    
        setCurrent(v.id);
    }
    
    return (
    <div className={styles.container}>
        {value.map((v, i) => {
            return (
                <div 
                    key={i}
                    onClick={() => onClick(v)}
                    className={
                        styles.btn + " " + (current === v.id ? styles.active:"")
                    }
                >
                    <div>
                        {v.label}
                        <p><b>{v.value}</b></p>
                    </div>
                </div>
            );
        })}

    </div>
    )
}
