Sebelumnya, saya ingin mengucapkan terima kasih telah memberikan saya kesempatan untuk mengikuti technical test magang di Jakmall. Saya juga ingin meminta maaf apabila website dari technical test yang saya buat jauh dari ekspetasi.
Hal tersebut dikarenakan sebelumnya, saya belum pernah belajar menggunakan React (hanya HTML, CSS, dan sedikit Laravel) dan saya baru mempelajarinya saat mengerjakan technical test ini.
Jika saya diterima magang di perusahaan ini, saya berjanji akan mempelajarinya seiring dengan berjalannya magang.
Berikut penjelasan dari apa yang saya buat:
- Pada step 1, tampilan yang saya buat menggunakan metode multi-step react-hook-form dengan validasi.
- Pada step 2, saya menampilkan pilihan untuk shipment dan payment yang berupa payment, serta ada summary sesuai dengan pilihan shipment dan payment yang dipilih.
- Pada step 3, website menampilkan ucapan terima kasih beserta order ID dan juga summary.


